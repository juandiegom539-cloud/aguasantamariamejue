import { useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDown,
  ArrowRight,
  Check,
  Droplets,
  Leaf,
  Mail,
  Menu,
  Minus,
  Mountain,
  Plus,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  X,
} from 'lucide-react';
import {
  Route,
  Redirect,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#087eaa',
    colorForeground: '#102d3f',
    colorMutedForeground: '#527280',
    colorDanger: '#b42318',
    colorBackground: '#f5fbfa',
    colorInput: '#ffffff',
    colorInputForeground: '#102d3f',
    colorNeutral: '#c6e0df',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '1rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#f5fbfa] rounded-[1.5rem] w-[440px] max-w-full overflow-hidden shadow-xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#102d3f] font-bold',
    headerSubtitle: 'text-[#527280]',
    socialButtonsBlockButtonText: 'text-[#102d3f] font-semibold',
    formFieldLabel: 'text-[#294d5d] font-semibold',
    footerActionLink: 'text-[#087eaa] font-bold',
    footerActionText: 'text-[#527280]',
    dividerText: 'text-[#527280]',
    identityPreviewEditButton: 'text-[#087eaa]',
    formFieldSuccessText: 'text-[#1a7d63]',
    alertText: 'text-[#b42318]',
    logoBox: 'h-12',
    logoImage: 'h-12 w-12',
    socialButtonsBlockButton: 'border-[#c6e0df] bg-white hover:bg-[#e8f6f5]',
    formButtonPrimary: 'bg-[#087eaa] hover:bg-[#075985] text-white font-bold',
    formFieldInput: 'border-[#c6e0df] bg-white text-[#102d3f]',
    footerAction: 'border-t border-[#c6e0df]',
    dividerLine: 'bg-[#c6e0df]',
    alert: 'border-[#f1c3bd] bg-[#fff4f2]',
    otpCodeFieldInput: 'border-[#c6e0df] bg-white text-[#102d3f]',
    formFieldRow: 'gap-2',
    main: 'gap-5',
  },
};

function AuthControls() {
  const { signOut } = useClerk();
  const { user, isLoaded } = useUser();
  const [, setLocation] = useLocation();
  const displayName = user?.firstName ?? user?.emailAddresses[0]?.emailAddress ?? 'Mi cuenta';

  if (!isLoaded) return null;

  return (
    <>
      <Show when="signed-out">
        <button
          type="button"
          onClick={() => setLocation('/sign-in')}
          className="focus-ring hidden rounded-full px-3 py-3 text-[11px] font-extrabold uppercase tracking-[.08em] text-[#075985] transition-colors hover:bg-[#e8f6f5] md:block"
          data-testid="button-sign-in"
        >
          Ingresar
        </button>
        <button
          type="button"
          onClick={() => setLocation('/sign-up')}
          className="focus-ring hidden rounded-full border border-[#b9d9d9] px-3 py-3 text-[11px] font-extrabold uppercase tracking-[.08em] text-[#075985] transition-colors hover:bg-[#e8f6f5] md:block"
          data-testid="button-sign-up"
        >
          Crear cuenta
        </button>
      </Show>
      <Show when="signed-in">
        <div className="hidden items-center gap-2 md:flex">
          <span className="max-w-[135px] truncate text-[11px] font-bold text-[#294d5d]" title={displayName}>
            {displayName}
          </span>
          <button
            type="button"
            onClick={() => signOut({ redirectUrl: basePath || '/' })}
            className="focus-ring rounded-full border border-[#b9d9d9] px-3 py-3 text-[11px] font-extrabold uppercase tracking-[.08em] text-[#075985] transition-colors hover:bg-[#e8f6f5]"
            data-testid="button-sign-out"
          >
            Salir
          </button>
        </div>
      </Show>
    </>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { signOut } = useClerk();
  const [quantities, setQuantities] = useState<Record<string, number>>({
    small: 1,
    jug: 1,
    large: 1,
  });

  const assets = {
    large: '/assets/WhatsApp_Image_2026-09-22_at_4.33.40_PM_1790112965498.jpeg',
    jug: '/assets/WhatsApp_Image_2026-09-22_at_4.13.56_PM_1790112990981.jpeg',
    small: '/assets/WhatsApp_Image_2026-09-22_at_4.37.22_PM_1790113052964.jpeg',
  };

  const products = [
    {
      id: 'small',
      label: '01 · Para compartir',
      name: 'Bolsas pequeñas',
      detail: 'x20 unidades',
      price: '$9.000',
      image: assets.small,
      alt: 'Seis bolsas pequeñas de agua Santa María Mejue de 360 mililitros',
      accent: 'bg-[#e6f7f4]',
    },
    {
      id: 'jug',
      label: '02 · Para la casa',
      name: 'Botellón',
      detail: '5 galones',
      price: '$10.000',
      image: assets.jug,
      alt: 'Botellón de cinco galones de Agua Santa María Mejue',
      accent: 'bg-[#e4f1f8]',
    },
    {
      id: 'large',
      label: '03 · Para rendir',
      name: 'Bolsa grande',
      detail: '6 litros',
      price: '$3.500',
      image: assets.large,
      alt: 'Bolsa grande de agua Santa María Mejue de 6 litros',
      accent: 'bg-[#eef5ec]',
    },
  ];

  const updateQuantity = (id: string, delta: number) => {
    setQuantities((current) => ({
      ...current,
      [id]: Math.max(1, Math.min(20, (current[id] ?? 1) + delta)),
    }));
  };

  const whatsappLink = (productName: string, quantity: number) =>
    `https://wa.me/573126672205?text=${encodeURIComponent(`Hola, quiero pedir ${productName}. ¿Me pueden confirmar disponibilidad y precio para ${quantity} ${quantity === 1 ? 'unidad' : 'unidades'}?`)}`;

  const jumpTo = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="site-shell min-h-[100dvh]">
      <header className="nav-blur fixed inset-x-0 top-0 z-50 border-b border-[#c6e0df]/70">
        <div className="mx-auto flex h-[76px] max-w-[1280px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <button
            type="button"
            onClick={() => jumpTo('inicio')}
            className="focus-ring flex items-center gap-3 text-left"
            data-testid="button-brand-home"
            aria-label="Ir al inicio de Agua Santa María Mejue"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#087eaa] text-white shadow-[0_5px_0_#075985]">
              <Droplets size={21} strokeWidth={2.2} />
            </span>
            <span className="leading-none">
              <span className="display-font block text-[18px] font-bold tracking-[-.03em] text-[#102d3f]">Santa María</span>
              <span className="mono-font mt-1 block text-[9px] font-medium uppercase tracking-[.18em] text-[#0d8bb8]">Mejue · agua pura</span>
            </span>
          </button>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Navegación principal">
            {[
              ['inicio', 'Inicio'],
              ['historia', 'De dónde venimos'],
              ['catalogo', 'Catálogo'],
              ['contacto', 'Contacto'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => jumpTo(id)}
                className="focus-ring mono-font text-[11px] font-medium uppercase tracking-[.08em] text-[#466779] transition-colors hover:text-[#0d8bb8]"
                data-testid={`button-nav-${id}`}
              >
                {label}
              </button>
            ))}
          </nav>
          <AuthControls />
          <button
            type="button"
            onClick={() => jumpTo('catalogo')}
            className="water-button focus-ring hidden items-center gap-2 rounded-full bg-[#f3bf3f] px-5 py-3 text-[11px] font-extrabold uppercase tracking-[.08em] text-[#102d3f] md:flex"
            data-testid="button-nav-order"
          >
            Pedir agua <ArrowRight size={15} />
          </button>
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            className="focus-ring rounded-full border border-[#b9d9d9] p-2.5 text-[#075985] md:hidden"
            data-testid="button-mobile-menu"
            aria-label={menuOpen ? 'Cerrar menú' : 'Abrir menú'}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
        {menuOpen && (
          <nav className="border-t border-[#c6e0df]/70 bg-[#f5fbfa] px-5 py-4 md:hidden" aria-label="Menú móvil">
            {[
              ['inicio', 'Inicio'],
              ['historia', 'De dónde venimos'],
              ['catalogo', 'Catálogo'],
              ['contacto', 'Contacto'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => jumpTo(id)}
                className="focus-ring mono-font block w-full border-b border-[#d9ebeb] py-4 text-left text-[11px] uppercase tracking-[.1em] text-[#466779]"
                data-testid={`button-mobile-nav-${id}`}
              >
                {label}
              </button>
            ))}
            <Show when="signed-out">
              <button type="button" onClick={() => { setMenuOpen(false); setLocation('/sign-in'); }} className="focus-ring block w-full border-b border-[#d9ebeb] py-4 text-left text-[11px] font-extrabold uppercase tracking-[.1em] text-[#075985]" data-testid="button-mobile-sign-in">
                Ingresar
              </button>
              <button type="button" onClick={() => { setMenuOpen(false); setLocation('/sign-up'); }} className="focus-ring block w-full py-4 text-left text-[11px] font-extrabold uppercase tracking-[.1em] text-[#075985]" data-testid="button-mobile-sign-up">
                Crear cuenta
              </button>
            </Show>
            <Show when="signed-in">
              <button type="button" onClick={() => { setMenuOpen(false); signOut({ redirectUrl: basePath || '/' }); }} className="focus-ring block w-full py-4 text-left text-[11px] font-extrabold uppercase tracking-[.1em] text-[#075985]" data-testid="button-mobile-sign-out">
                Cerrar sesión
              </button>
            </Show>
          </nav>
        )}
      </header>

      <main>
        <section id="inicio" className="hero-grain relative overflow-hidden bg-[#087eaa] pt-[76px] text-[#f5fbfa]">
          <div className="hero-watermark pointer-events-none absolute -right-5 top-[26%] z-0">agua</div>
          <div className="relative z-10 mx-auto grid max-w-[1280px] items-center gap-12 px-5 pb-20 pt-16 sm:px-8 sm:pt-24 lg:grid-cols-[1.02fr_.98fr] lg:gap-16 lg:px-12 lg:pb-28 lg:pt-28">
            <div>
              <div className="reveal reveal-delay-1 eyebrow mb-7 flex items-center gap-3 text-[#b9f2e9]">
                <span className="h-px w-8 bg-[#b9f2e9]" /> Desde Toledo, Norte de Santander
              </div>
              <h1 className="reveal reveal-delay-2 display-font max-w-[650px] text-[clamp(3.5rem,8vw,7.4rem)] font-semibold leading-[.88] tracking-[-.07em]">
                Agua que<br /><span className="text-[#f3bf3f]">nace cerca.</span>
              </h1>
              <p className="reveal reveal-delay-3 mt-8 max-w-[475px] text-[17px] leading-8 text-[#dbf5f3] sm:text-[19px]">
                Agua Santa María Mejue llega desde nuestra tierra a la tuya: fresca, confiable y lista para acompañar los días de nuestra comunidad.
              </p>
              <div className="reveal reveal-delay-4 mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
                <button type="button" onClick={() => jumpTo('catalogo')} className="water-button focus-ring inline-flex items-center gap-3 rounded-full bg-[#f3bf3f] px-6 py-4 text-[12px] font-extrabold uppercase tracking-[.08em] text-[#102d3f]" data-testid="button-hero-catalog">
                  Ver productos <ArrowDown size={16} />
                </button>
                <button type="button" onClick={() => jumpTo('historia')} className="focus-ring inline-flex items-center gap-2 rounded-full px-3 py-3 text-[12px] font-bold text-[#e2faf7] underline decoration-[#72d8c5] underline-offset-8 transition-colors hover:text-[#f3bf3f]" data-testid="button-hero-story">
                  Conocer la historia <ArrowRight size={15} />
                </button>
              </div>
              <div className="mt-14 flex flex-wrap gap-x-8 gap-y-4 border-t border-[#54b9c9]/60 pt-5">
                <div>
                  <span className="mono-font block text-[10px] uppercase tracking-[.14em] text-[#9de4dc]">Origen</span>
                  <span className="mt-1 block text-[14px] font-semibold">Vereda Santa María</span>
                </div>
                <div>
                  <span className="mono-font block text-[10px] uppercase tracking-[.14em] text-[#9de4dc]">Entrega</span>
                  <span className="mt-1 block text-[14px] font-semibold">Solo Toledo</span>
                </div>
              </div>
            </div>
            <div className="relative mx-auto w-full max-w-[550px]">
              <div className="float-slow relative z-10 mx-auto w-[82%]">
                <div className="hero-visual overflow-hidden rounded-[2.2rem] border-[10px] border-white/80 bg-white">
                  <img src={assets.jug} alt="Botellón de cinco galones Agua Santa María Mejue con gotas de agua" className="aspect-square w-full object-cover" data-testid="img-hero-jug" />
                </div>
              </div>
              <div className="absolute -bottom-5 left-0 z-20 rounded-2xl border border-white/70 bg-[#f5fbfa] px-5 py-4 text-[#102d3f] shadow-xl">
                <div className="flex items-center gap-2 text-[#0d8bb8]"><ShieldCheck size={17} /><span className="mono-font text-[10px] uppercase tracking-[.12em]">Para todos los días</span></div>
                <p className="display-font mt-1 text-[18px] font-semibold">Pura desde el origen.</p>
              </div>
              <div className="absolute -right-2 top-8 z-20 flex h-20 w-20 rotate-12 items-center justify-center rounded-full bg-[#f3bf3f] text-center text-[#102d3f] shadow-lg sm:-right-5">
                <span className="mono-font text-[10px] font-bold uppercase leading-3">Agua<br />local</span>
              </div>
              <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full border border-[#7ed9d5]/30" />
            </div>
          </div>
          <div className="mountain-strip h-24" aria-hidden="true" />
        </section>

        <section className="border-b border-[#c6e0df] bg-[#e5f5f1]">
          <div className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-5 px-5 py-5 sm:px-8 lg:px-12">
            <p className="display-font text-[20px] font-semibold text-[#075985]">Lo que refresca a Toledo.</p>
            <div className="flex flex-wrap gap-5 text-[#356879]">
              <span className="flex items-center gap-2 text-[12px] font-semibold"><Droplets size={16} className="text-[#0d8bb8]" /> Fresca</span>
              <span className="flex items-center gap-2 text-[12px] font-semibold"><Leaf size={16} className="text-[#1a7d63]" /> Cercana</span>
              <span className="flex items-center gap-2 text-[12px] font-semibold"><ShieldCheck size={16} className="text-[#0d8bb8]" /> Confiable</span>
            </div>
          </div>
        </section>

        <section id="historia" className="mx-auto max-w-[1280px] scroll-mt-24 px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
          <div className="grid items-center gap-14 lg:grid-cols-[.82fr_1.18fr] lg:gap-24">
            <div className="relative">
              <div className="absolute -left-5 -top-5 h-28 w-28 rounded-full border border-[#4bbca9] lg:-left-8 lg:-top-8" />
              <div className="relative overflow-hidden rounded-[2.2rem] bg-[#d9f2ef] p-5 sm:p-8">
                <img src={assets.large} alt="Bolsa grande de seis litros de Agua Santa María Mejue" className="relative z-10 mx-auto aspect-[.82] max-h-[550px] w-full rounded-[1.5rem] object-cover object-center shadow-2xl" data-testid="img-story-large" />
                <div className="absolute bottom-7 left-7 z-20 rounded-xl bg-[#f3bf3f] px-4 py-3 shadow-lg">
                  <span className="mono-font block text-[9px] font-bold uppercase tracking-[.14em]">Nuestro lugar</span>
                  <span className="mt-1 block text-[14px] font-bold">Toledo, NS</span>
                </div>
              </div>
            </div>
            <div>
              <p className="eyebrow text-[#0d8bb8]">Una historia de aquí</p>
              <h2 className="display-font mt-5 max-w-[650px] text-[clamp(2.6rem,5vw,5.3rem)] font-semibold leading-[.96] tracking-[-.055em] text-[#102d3f]">
                De nuestra vereda,<br /><span className="text-[#0d8bb8]">para la tuya.</span>
              </h2>
              <p className="mt-7 max-w-[565px] text-[17px] leading-8 text-[#527280]">
                Santa María Mejue es una marca local hecha para estar cerca. Nuestra agua se embotella en la vereda Santa María, finca Padigma, por la vía Toledo–Labateca.
              </p>
              <div className="mt-10 grid max-w-[590px] gap-4 sm:grid-cols-3">
                {[
                  ['Origen', 'Vereda Santa María'],
                  ['Alcance', 'Toledo, Norte de Santander'],
                  ['Contacto', 'Pedido directo'],
                ].map(([title, detail]) => (
                  <div key={title} className="border-t-2 border-[#b9dedd] pt-4">
                    <span className="mono-font block text-[10px] uppercase tracking-[.12em] text-[#0d8bb8]">{title}</span>
                    <span className="mt-2 block text-[13px] font-bold leading-5 text-[#294d5d]">{detail}</span>
                  </div>
                ))}
              </div>
              <div className="mt-11 flex items-center gap-3 text-[#1a7d63]">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#d8f0e9]"><Mountain size={17} /></span>
                <span className="text-[13px] font-bold">Un sabor que reconoce el territorio</span>
              </div>
            </div>
          </div>
        </section>

        <section id="catalogo" className="scroll-mt-24 bg-[#e8f6f5] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1280px]">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div>
                <p className="eyebrow text-[#0d8bb8]">Catálogo local</p>
                <h2 className="display-font mt-4 max-w-[650px] text-[clamp(2.7rem,5vw,5.2rem)] font-semibold leading-[.94] tracking-[-.06em] text-[#102d3f]">
                  Elige el tamaño<br /><span className="text-[#0d8bb8]">para tu día.</span>
                </h2>
              </div>
              <div className="max-w-[290px] border-l-2 border-[#f3bf3f] pl-4 text-[14px] leading-6 text-[#527280]">
                <span className="font-bold text-[#102d3f]">¿Listo para pedir?</span><br />
                Elige un producto, indica la cantidad y escríbenos por WhatsApp.
              </div>
            </div>
            <div className="mt-14 grid gap-5 lg:grid-cols-3">
              {products.map((product) => (
                <article key={product.id} className="product-card overflow-hidden rounded-[1.65rem] border border-[#c9e3e2] bg-[#f8fcfb]" data-testid={`card-product-${product.id}`}>
                  <div className={`product-image-wrap relative flex h-[290px] items-center justify-center overflow-hidden ${product.accent}`}>
                    <span className="absolute left-5 top-5 z-10 rounded-full bg-[#f5fbfa]/80 px-3 py-2 mono-font text-[9px] font-medium uppercase tracking-[.12em] text-[#356879]">{product.label}</span>
                    <img src={product.image} alt={product.alt} className={`h-full w-full ${product.id === 'jug' ? 'object-cover' : 'object-contain'} ${product.id === 'large' ? 'p-4' : ''}`} data-testid={`img-product-${product.id}`} />
                    <span className="absolute bottom-4 right-4 flex h-8 w-8 items-center justify-center rounded-full bg-[#f5fbfa]/80 text-[#0d8bb8]" aria-hidden="true"><Droplets size={15} /></span>
                  </div>
                  <div className="p-6 sm:p-7">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="display-font text-[28px] font-semibold leading-none text-[#102d3f]">{product.name}</h3>
                        <p className="mt-2 text-[14px] font-semibold text-[#527280]">{product.detail}</p>
                      </div>
                      <span className="shrink-0 text-right text-[13px] font-extrabold text-[#075985]">{product.price}</span>
                    </div>
                    <div className="mt-7 flex items-center justify-between border-t border-[#d7e9e7] pt-5">
                      <div className="flex items-center gap-2" aria-label={`Cantidad de ${product.name}`}>
                        <button type="button" onClick={() => updateQuantity(product.id, -1)} className="focus-ring flex h-8 w-8 items-center justify-center rounded-full border border-[#bcdad9] text-[#075985] transition-colors hover:bg-[#dff1ef]" data-testid={`button-decrease-${product.id}`} aria-label={`Disminuir cantidad de ${product.name}`}><Minus size={14} /></button>
                        <span className="mono-font w-6 text-center text-[13px] font-medium text-[#102d3f]" data-testid={`text-quantity-${product.id}`}>{quantities[product.id]}</span>
                        <button type="button" onClick={() => updateQuantity(product.id, 1)} className="focus-ring flex h-8 w-8 items-center justify-center rounded-full border border-[#bcdad9] text-[#075985] transition-colors hover:bg-[#dff1ef]" data-testid={`button-increase-${product.id}`} aria-label={`Aumentar cantidad de ${product.name}`}><Plus size={14} /></button>
                      </div>
                      <a href={whatsappLink(`${product.name} · ${product.detail}`, quantities[product.id])} target="_blank" rel="noreferrer" className="water-button focus-ring inline-flex items-center gap-2 rounded-full bg-[#075985] px-4 py-3 text-[11px] font-extrabold uppercase tracking-[.06em] text-white" data-testid={`link-order-${product.id}`}>
                        Pedir <ArrowRight size={14} />
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <div className="mt-7 flex flex-col gap-3 rounded-2xl border border-[#bddbd8] bg-[#dff1ef] px-5 py-4 text-[13px] text-[#356879] sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <span className="flex items-center gap-2 font-bold"><Check size={17} className="text-[#1a7d63]" /> Envíos únicamente a Toledo, Norte de Santander</span>
              <span className="mono-font text-[10px] uppercase tracking-[.1em] text-[#527280]">Pedido directo por WhatsApp</span>
            </div>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#102d3f] px-5 py-24 text-[#f5fbfa] sm:px-8 lg:px-12 lg:py-32">
          <div className="absolute -right-16 -top-24 h-80 w-80 rounded-full border border-[#4ebbae]/30" />
          <div className="absolute -bottom-32 left-1/3 h-96 w-96 rounded-full border border-[#4ebbae]/20" />
          <div className="relative mx-auto grid max-w-[1280px] items-center gap-12 lg:grid-cols-[1.25fr_.75fr]">
            <div>
              <p className="eyebrow text-[#7fe1d0]">Tu agua, más cerca</p>
              <h2 className="display-font mt-5 max-w-[760px] text-[clamp(2.8rem,6vw,6.5rem)] font-semibold leading-[.9] tracking-[-.06em]">
                Refrescarse también es <span className="text-[#f3bf3f]">hacer barrio.</span>
              </h2>
              <p className="mt-7 max-w-[560px] text-[16px] leading-8 text-[#b9d5d7]">
                Cuando eliges Santa María Mejue, eliges una opción de aquí, con atención directa y entregas pensadas para nuestra gente.
              </p>
            </div>
            <div className="relative rounded-[1.8rem] border border-[#4c7180] bg-[#193f50] p-7 sm:p-9">
              <Sparkles size={23} className="text-[#f3bf3f]" />
              <p className="display-font mt-8 text-[28px] font-semibold leading-tight">“Pídela hoy y la ponemos en camino.”</p>
              <div className="mt-8 h-px bg-[#477181]" />
              <p className="mono-font mt-4 text-[10px] uppercase tracking-[.12em] text-[#9dcacc]">Agua Santa María Mejue</p>
            </div>
          </div>
        </section>

        <section id="contacto" className="scroll-mt-24 bg-[#f5fbfa] px-5 py-24 sm:px-8 lg:px-12 lg:py-28">
          <div className="mx-auto grid max-w-[1280px] gap-14 lg:grid-cols-[1fr_.95fr] lg:gap-24">
            <div>
              <p className="eyebrow text-[#0d8bb8]">Estamos para atenderte</p>
              <h2 className="display-font mt-4 text-[clamp(2.7rem,5vw,5rem)] font-semibold leading-[.94] tracking-[-.06em] text-[#102d3f]">Hablemos de<br /><span className="text-[#0d8bb8]">tu pedido.</span></h2>
              <p className="mt-7 max-w-[460px] text-[16px] leading-8 text-[#527280]">Escríbenos para confirmar disponibilidad, cantidades y coordinar tu entrega dentro de Toledo.</p>
              <a href="mailto:juandiegom539@gmail.com" className="focus-ring mt-8 inline-flex items-center gap-3 rounded-full border border-[#bddbd8] bg-[#e8f6f5] px-5 py-4 text-[13px] font-bold text-[#075985] transition-colors hover:bg-[#dff1ef]" data-testid="link-support-email">
                <Mail size={18} /> juandiegom539@gmail.com
              </a>
            </div>
            <div className="rounded-[1.8rem] bg-[#e5f5f1] p-7 sm:p-10">
              <p className="eyebrow text-[#1a7d63]">Información de entrega</p>
              <div className="mt-8 space-y-6">
                <div className="flex gap-4 border-b border-[#c5e1de] pb-6">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f3bf3f] text-[#102d3f]"><Mountain size={17} /></span>
                  <div><p className="font-bold text-[#102d3f]">Cobertura</p><p className="mt-1 text-[14px] leading-6 text-[#527280]">Envíos únicamente a Toledo, Norte de Santander.</p></div>
                </div>
                <div className="flex gap-4 border-b border-[#c5e1de] pb-6">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#bde8df] text-[#075985]"><ShoppingBag size={17} /></span>
                  <div><p className="font-bold text-[#102d3f]">Cómo comprar</p><p className="mt-1 text-[14px] leading-6 text-[#527280]">Selecciona un producto en el catálogo y envíanos tu cantidad por WhatsApp.</p></div>
                </div>
                <div className="flex gap-4">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#cfe8f1] text-[#075985]"><Droplets size={17} /></span>
                  <div><p className="font-bold text-[#102d3f]">Atención directa</p><p className="mt-1 text-[14px] leading-6 text-[#527280]">Te respondemos para coordinar cada pedido.</p></div>
                </div>
              </div>
              <a href="https://wa.me/573126672205?text=Hola%2C%20quiero%20hacer%20un%20pedido%20de%20Agua%20Santa%20Mar%C3%ADa%20Mejue.%20%C2%BFMe%20ayudan%20con%20la%20disponibilidad%3F" target="_blank" rel="noreferrer" className="water-button focus-ring mt-9 flex w-full items-center justify-center gap-3 rounded-full bg-[#075985] px-5 py-4 text-[12px] font-extrabold uppercase tracking-[.08em] text-white" data-testid="link-contact-whatsapp">
                Escribir por WhatsApp <ArrowRight size={16} />
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#c6e0df] bg-[#e5f5f1] px-5 py-8 sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-[1280px] flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#087eaa] text-white"><Droplets size={16} /></span>
            <span className="display-font text-[17px] font-bold text-[#102d3f]">Agua Santa María Mejue</span>
          </div>
          <p className="mono-font text-[9px] uppercase tracking-[.12em] text-[#527280]">Agua local · Toledo, Norte de Santander</p>
          <p className="text-[11px] text-[#527280]">Hecha cerca, para los días de aquí.</p>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/user-portal" component={UserPortal} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/user-portal" />
      </Show>
      <Show when="signed-out">
        <Home />
      </Show>
    </>
  );
}

function UserPortal() {
  return (
    <>
      <Show when="signed-in">
        <Home />
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#e5f5f1] px-4 py-10">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#e5f5f1] px-4 py-10">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: 'Bienvenido de nuevo',
            subtitle: 'Ingresa para continuar con tu cuenta',
          },
        },
        signUp: {
          start: {
            title: 'Crea tu cuenta',
            subtitle: 'Empieza a disfrutar Agua Santa María Mejue',
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
